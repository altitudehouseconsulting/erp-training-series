-- FI_GLAccounts --------------------------------------------


CREATE SCHEMA FI_MM;

CREATE TABLE FI_MM.SKA1 ( -- G/L Account Master (Chart of Accounts Level)
    SAKNR VARCHAR(10) PRIMARY KEY,  -- G/L Account
    KTOKS VARCHAR(4),               -- Account Group
    TXT20 VARCHAR(20)               -- Short Description
);

CREATE TABLE FI_MM.SKB1 ( -- G/L Account Master (Company Code Level)
    SAKNR VARCHAR(10),
    BUKRS VARCHAR(4),               -- Company Code
    WAERS VARCHAR(5),               -- Currency
    XOPVW CHAR(1),                  -- Open Item Mgmt
    PRIMARY KEY (SAKNR, BUKRS),
    FOREIGN KEY (SAKNR) REFERENCES FI_MM.SKA1(SAKNR)
);

CREATE TABLE FI_MM.SKAT ( -- G/L Account Descriptions
    SAKNR VARCHAR(10),
    SPRAS VARCHAR(2),               -- Language Key
    TXT50 VARCHAR(50),             -- Long Description
    PRIMARY KEY (SAKNR, SPRAS),
    FOREIGN KEY (SAKNR) REFERENCES FI_MM.SKA1(SAKNR)
);

-- FI_Postings ----------------------------------------------

CREATE TABLE FI_MM.BKPF ( -- Document Header
    BELNR VARCHAR(10) PRIMARY KEY,  -- Document Number
    BUKRS VARCHAR(4),               -- Company Code
    GJAHR VARCHAR(4),               -- Fiscal Year
    BLART VARCHAR(2),               -- Document Type
    BLDAT DATE                      -- Document Date
);

CREATE TABLE FI_MM.BSEG ( -- Line Items
    BELNR VARCHAR(10),
    BUZEI VARCHAR(3),               -- Line Item Number
    SAKNR VARCHAR(10),              -- G/L Account
    DMBTR DECIMAL(15, 2),           -- Amount
    WRBTR DECIMAL(15, 2),           -- Amount in Foreign Currency
    PRIMARY KEY (BELNR, BUZEI),
    FOREIGN KEY (BELNR) REFERENCES FI_MM.BKPF(BELNR),
    FOREIGN KEY (SAKNR) REFERENCES FI_MM.SKA1(SAKNR)
);

-- MM_Materials ---------------------------------------------

CREATE TABLE FI_MM.MARA ( -- Material Master
    MATNR VARCHAR(18) PRIMARY KEY, -- Material Number
    MTART VARCHAR(4),              -- Material Type
    MBRSH VARCHAR(1)               -- Industry Sector
);

CREATE TABLE FI_MM.MAKT ( -- Material Descriptions
    MATNR VARCHAR(18),
    SPRAS VARCHAR(2),              -- Language
    MAKTX VARCHAR(40),             -- Description
    PRIMARY KEY (MATNR, SPRAS),
    FOREIGN KEY (MATNR) REFERENCES FI_MM.MARA(MATNR)
);

-- MM_PurchaseOrders ----------------------------------------

CREATE TABLE FI_MM.EKKO ( -- Purchase Order Header
    EBELN VARCHAR(10) PRIMARY KEY, -- PO Number
    LIFNR VARCHAR(10),             -- Vendor Number
    BUKRS VARCHAR(4),              -- Company Code
    BEDAT DATE                     -- PO Date
);

CREATE TABLE FI_MM.EKPO ( -- Purchase Order Items
    EBELN VARCHAR(10),
    EBELP VARCHAR(5),              -- PO Item Number
    MATNR VARCHAR(18),             -- Material Number
    MENGE DECIMAL(13,3),           -- Quantity
    PRIMARY KEY (EBELN, EBELP),
    FOREIGN KEY (EBELN) REFERENCES FI_MM.EKKO(EBELN),
    FOREIGN KEY (MATNR) REFERENCES FI_MM.MARA(MATNR)
);
