
-- Star Schema: Financial Accounting (FI)
CREATE VIEW DimGLAccount AS
SELECT a.SAKNR AS AccountID, a.KTOKS AS AccountGroup, t.TXT50 AS Description
FROM FI_MM.SKA1 a
LEFT JOIN FI_MM.SKAT t ON a.SAKNR = t.SAKNR AND t.SPRAS = 'EN';

CREATE VIEW DimCompanyCode AS
SELECT DISTINCT BUKRS AS CompanyCode
FROM FI_MM.SKB1;

CREATE VIEW FactGLPostings AS
SELECT 
    b.BELNR AS DocumentID,
    b.BUKRS AS CompanyCode,
    h.BLDAT AS DocumentDate,
    b.SAKNR AS AccountID,
    b.DMBTR AS LocalAmount,
    b.WRBTR AS ForeignAmount
FROM FI_MM.BSEG b
JOIN FI_MM.BKPF h ON b.BELNR = h.BELNR;

-- Star Schema: Purchase Orders (MM)
CREATE VIEW DimMaterial AS
SELECT m.MATNR AS MaterialID, t.MAKTX AS MaterialName, m.MTART AS MaterialType
FROM FI_MM.MARA m
LEFT JOIN FI_MM.MAKT t ON m.MATNR = t.MATNR AND t.SPRAS = 'EN';

CREATE VIEW DimPOHeader AS
SELECT EBELN AS PONumber, LIFNR AS VendorID, BUKRS AS CompanyCode, BEDAT AS PODate
FROM FI_MM.EKKO;

CREATE VIEW FactPurchaseOrder AS
SELECT 
    p.EBELN AS PONumber,
    p.EBELP AS POItemNumber,
    p.MATNR AS MaterialID,
    p.MENGE AS Quantity
FROM FI_MM.EKPO p;
