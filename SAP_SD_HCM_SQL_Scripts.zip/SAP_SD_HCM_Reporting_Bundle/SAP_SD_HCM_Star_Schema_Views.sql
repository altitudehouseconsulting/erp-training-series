
-- Star Schema: Sales & Distribution (SD)

CREATE VIEW vwDimCustomer AS
SELECT KUNNR AS CustomerID, NAME1 AS CustomerName, LAND1 AS Country
FROM KNA1;

CREATE VIEW vwFactSalesOrders AS
SELECT 
    i.VBELN AS SalesOrderID,
    h.KUNNR AS CustomerID,
    i.MATNR AS MaterialID,
    h.AUDAT AS OrderDate,
    i.KWMENG AS Quantity
FROM SD_HCM.VBAP i
JOIN SD_HCM.VBAK h ON i.VBELN = h.VBELN;

-- Star Schema: Human Capital Management (HCM)

CREATE VIEW vwDimEmployee AS
SELECT p.PERNR AS EmployeeID, d.VORNA AS FirstName, d.NACHN AS LastName, d.GESCH AS Gender,
       p.BUKRS AS CompanyCode, p.WERKS AS WorkLocation
FROM SD_HCM.PA0001 p
JOIN SD_HCM.PA0002 d ON p.PERNR = d.PERNR;

CREATE VIEW vwDimDate AS
SELECT DISTINCT PAYDT AS Date
FROM SD_HCM.PAYROLL;

CREATE VIEW vwFactPayroll AS
SELECT 
    PAYID AS PayrollID,
    PERNR AS EmployeeID,
    PAYDT AS PayDate,
    GROSS AS GrossPay,
    NET AS NetPay
FROM SD_HCM.PAYROLL;
