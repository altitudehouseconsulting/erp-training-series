
-- =====================
-- DELTEK ERP BASE TABLES
-- =====================

-- GENERAL LEDGER
CREATE TABLE GL_ACCOUNTS (
    account_id INT PRIMARY KEY,
    account_name VARCHAR(100),
    account_type VARCHAR(50)
);

CREATE TABLE GL_PERIODS (
    period_id INT PRIMARY KEY,
    fiscal_year INT,
    period_number INT,
    start_date DATE,
    end_date DATE
);

CREATE TABLE GL_TRANSACTIONS (
    transaction_id INT PRIMARY KEY,
    account_id INT,
    period_id INT,
    amount DECIMAL(18,2),
    transaction_date DATE,
    description VARCHAR(255),
    FOREIGN KEY (account_id) REFERENCES GL_ACCOUNTS(account_id),
    FOREIGN KEY (period_id) REFERENCES GL_PERIODS(period_id)
);

-- PROJECTS & COSTING
CREATE TABLE PROJECTS (
    project_id INT PRIMARY KEY,
    project_name VARCHAR(100),
    customer_id INT,
    project_type VARCHAR(50),
    start_date DATE,
    end_date DATE
);

CREATE TABLE PROJECT_TASKS (
    task_id INT PRIMARY KEY,
    project_id INT,
    task_name VARCHAR(100),
    FOREIGN KEY (project_id) REFERENCES PROJECTS(project_id)
);

CREATE TABLE PROJECT_BUDGETS (
    budget_id INT PRIMARY KEY,
    project_id INT,
    budget_amount DECIMAL(18,2),
    fiscal_year INT,
    FOREIGN KEY (project_id) REFERENCES PROJECTS(project_id)
);

CREATE TABLE PROJECT_ACTUALS (
    actual_id INT PRIMARY KEY,
    project_id INT,
    task_id INT,
    amount DECIMAL(18,2),
    date_recorded DATE,
    FOREIGN KEY (project_id) REFERENCES PROJECTS(project_id),
    FOREIGN KEY (task_id) REFERENCES PROJECT_TASKS(task_id)
);

-- TIME & LABOR
CREATE TABLE EMPLOYEES (
    employee_id INT PRIMARY KEY,
    employee_name VARCHAR(100),
    labor_category VARCHAR(50)
);

CREATE TABLE TIMESHEETS (
    timesheet_id INT PRIMARY KEY,
    employee_id INT,
    submission_date DATE,
    FOREIGN KEY (employee_id) REFERENCES EMPLOYEES(employee_id)
);

CREATE TABLE TIMESHEET_ENTRIES (
    entry_id INT PRIMARY KEY,
    timesheet_id INT,
    project_id INT,
    task_id INT,
    hours_worked DECIMAL(5,2),
    work_date DATE,
    FOREIGN KEY (timesheet_id) REFERENCES TIMESHEETS(timesheet_id),
    FOREIGN KEY (project_id) REFERENCES PROJECTS(project_id),
    FOREIGN KEY (task_id) REFERENCES PROJECT_TASKS(task_id)
);

-- ACCOUNTS PAYABLE
CREATE TABLE VENDORS (
    vendor_id INT PRIMARY KEY,
    vendor_name VARCHAR(100)
);

CREATE TABLE AP_INVOICES (
    invoice_id INT PRIMARY KEY,
    vendor_id INT,
    amount DECIMAL(18,2),
    invoice_date DATE,
    due_date DATE,
    FOREIGN KEY (vendor_id) REFERENCES VENDORS(vendor_id)
);

CREATE TABLE AP_PAYMENTS (
    payment_id INT PRIMARY KEY,
    invoice_id INT,
    payment_date DATE,
    amount_paid DECIMAL(18,2),
    FOREIGN KEY (invoice_id) REFERENCES AP_INVOICES(invoice_id)
);

-- ACCOUNTS RECEIVABLE
CREATE TABLE CUSTOMERS (
    customer_id INT PRIMARY KEY,
    customer_name VARCHAR(100)
);

CREATE TABLE AR_INVOICES (
    ar_invoice_id INT PRIMARY KEY,
    customer_id INT,
    project_id INT,
    invoice_amount DECIMAL(18,2),
    invoice_date DATE,
    due_date DATE,
    FOREIGN KEY (customer_id) REFERENCES CUSTOMERS(customer_id),
    FOREIGN KEY (project_id) REFERENCES PROJECTS(project_id)
);

CREATE TABLE AR_PAYMENTS (
    ar_payment_id INT PRIMARY KEY,
    ar_invoice_id INT,
    payment_date DATE,
    amount_received DECIMAL(18,2),
    FOREIGN KEY (ar_invoice_id) REFERENCES AR_INVOICES(ar_invoice_id)
);

-- BILLING & CONTRACTS
CREATE TABLE CONTRACTS (
    contract_id INT PRIMARY KEY,
    project_id INT,
    billing_type VARCHAR(50),
    start_date DATE,
    end_date DATE,
    FOREIGN KEY (project_id) REFERENCES PROJECTS(project_id)
);
