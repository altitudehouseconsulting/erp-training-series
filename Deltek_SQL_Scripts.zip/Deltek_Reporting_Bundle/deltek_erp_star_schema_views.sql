
-- =======================================
-- DELTEK ERP STAR SCHEMA REPORTING VIEWS
-- =======================================

-- DIMENSION VIEWS

CREATE VIEW dim_project AS
SELECT 
    p.project_id,
    p.project_name,
    p.project_type,
    p.start_date,
    p.end_date,
    c.customer_name
FROM PROJECTS p
LEFT JOIN CUSTOMERS c ON p.customer_id = c.customer_id;

CREATE VIEW dim_employee AS
SELECT 
    employee_id,
    employee_name,
    labor_category
FROM EMPLOYEES;

CREATE VIEW dim_vendor AS
SELECT 
    vendor_id,
    vendor_name
FROM VENDORS;

CREATE VIEW dim_customer AS
SELECT 
    customer_id,
    customer_name
FROM CUSTOMERS;

CREATE VIEW dim_account AS
SELECT 
    account_id,
    account_name,
    account_type
FROM GL_ACCOUNTS;

CREATE VIEW dim_time AS
SELECT 
    period_id,
    fiscal_year,
    period_number,
    start_date,
    end_date
FROM GL_PERIODS;

-- FACT VIEWS

CREATE VIEW fact_timesheet_hours AS
SELECT 
    te.entry_id,
    te.employee_id,
    te.project_id,
    te.task_id,
    te.hours_worked,
    te.work_date
FROM TIMESHEET_ENTRIES te;

CREATE VIEW fact_project_costs AS
SELECT 
    pa.actual_id,
    pa.project_id,
    pa.task_id,
    pa.amount,
    pa.date_recorded
FROM PROJECT_ACTUALS pa;

CREATE VIEW fact_gl_transactions AS
SELECT 
    gt.transaction_id,
    gt.account_id,
    gt.period_id,
    gt.amount,
    gt.transaction_date
FROM GL_TRANSACTIONS gt;

CREATE VIEW fact_ap_payments AS
SELECT 
    ap.payment_id,
    ai.vendor_id,
    ap.amount_paid,
    ap.payment_date
FROM AP_PAYMENTS ap
JOIN AP_INVOICES ai ON ap.invoice_id = ai.invoice_id;

CREATE VIEW fact_ar_collections AS
SELECT 
    arp.ar_payment_id,
    ai.customer_id,
    arp.amount_received,
    arp.payment_date
FROM AR_PAYMENTS arp
JOIN AR_INVOICES ai ON arp.ar_invoice_id = ai.ar_invoice_id;

CREATE VIEW fact_contracts AS
SELECT 
    contract_id,
    project_id,
    billing_type,
    start_date,
    end_date
FROM CONTRACTS;
