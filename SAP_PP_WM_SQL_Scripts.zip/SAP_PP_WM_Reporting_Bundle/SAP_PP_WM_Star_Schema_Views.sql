
-- PP
CREATE VIEW vwDimWorkCenter AS 
SELECT 
OBJID AS WorkCenterID, 
ARBPL AS CenterName, 
WERKS AS Plant 
FROM PP_WM.CRHD;

CREATE VIEW vwFactProductionOrder AS 
SELECT AUFNR AS ProductionOrderID, 
MATNR AS MaterialID, 
OBJID AS WorkCenterID, 
GSTRP AS StartDate, 
GLTRP AS EndDate 
FROM PP_WM.AFKO;

-- WM
CREATE VIEW vwDimStorageBin AS 
SELECT LGPLA AS BinID, 
LGTYP AS StorageType, 
LGNUM AS WarehouseNumber 
FROM PP_WM.LAGP;

CREATE VIEW vwFactQuants AS 
SELECT LGPLA AS BinID, 
MATNR AS MaterialID, 
VERME AS Quantity, 
MEINS AS Unit 
FROM PP_WM.LQUA;

CREATE VIEW vwFactTransferOrders AS 
SELECT TANUM AS TransferOrderID, 
POSNR AS LineNumber, 
LGPLA AS BinID, 
MATNR AS MaterialID, 
MENGE AS TransferQuantity 
FROM PP_WM.LTAP;
